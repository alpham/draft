#!/usr/bin/python
# -*- coding: utf-8 -*-


import facebook
import sys
import codecs

#this token can access data for a period of time...
token = 'CAACEdEose0cBAHvsJv7yo1qlnDQIZBuaGBpwJjpapCqe274ijg4wA7nj5KMrM5g6b1YXw1QCRAQZBZB7Jk3dNkP1HiIQ5kUAWTvivyRsZCJaAOUT8IaZBZBZCu6zE6NpNbYxAyFy2W0YMZCu0ZCvTpPGZB1STbGUxPnKR3aqBe2geBhMZAuvK8H8YR4osCvvMHQmsJZBqCZCK5FxVogZDZD'
account_id = "Ahmed.Magdy40"
graph = facebook.GraphAPI(token)
# get only statuses...
posts = graph.get_connections(account_id, "statuses")
# try to user facebook graph api to understand the result structure...
posts_list = [post['message'] for post in posts['data']]

input_file = codecs.open('input_data.txt','w',encoding='utf-8')
for one_post in posts_list :
     input_file.write(one_post + "\n")
input_file.close()
